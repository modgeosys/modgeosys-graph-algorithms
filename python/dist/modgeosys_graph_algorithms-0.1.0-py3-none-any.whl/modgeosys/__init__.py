"""Root package for modgeosys (Kevin Weller)."""
