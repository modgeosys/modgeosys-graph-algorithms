"""Navigation algorithms."""
